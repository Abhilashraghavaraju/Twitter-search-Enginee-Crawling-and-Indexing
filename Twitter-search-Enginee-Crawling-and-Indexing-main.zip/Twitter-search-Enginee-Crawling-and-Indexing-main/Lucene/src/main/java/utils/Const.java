package utils;
import java.util.ArrayList;
import java.util.*;

public class Const{
    public static ArrayList<String> indexFieldList = new ArrayList<String>(
                                                Arrays.asList("text", "hashtags","timestamp",
                                                             "location","username","userscreenname",
                                                             "userimageurl","likedcount","links"));

}