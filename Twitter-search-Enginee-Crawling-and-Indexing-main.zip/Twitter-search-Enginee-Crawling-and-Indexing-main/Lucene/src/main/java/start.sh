#!/bin/sh
java beep.jar