twitter = {
           'consumer_key': 'mrGUrHZIaYn91udMBxyHl0YcN',
           'consumer_secret': 'i2DUXJbXuIBrZQHCYT5q8nl3PSKCxrXGxqzc2yqfqAoG8aGZzI',
           'access_key': '1077892730980843521-rcEFWONhgOlLIWiF8VW2xCrWb56OMC',
           'access_secret': 'uhf5Bk2E7OvqGt2pHPiytVvOa6DrMcdp1z6SayoL5ZnRa',
           'bearer_token' : 'AAAAAAAAAAAAAAAAAAAAAGAeYgEAAAAAWy3Sfto48GGag%2BP9mlTOdQG0FUg%3DWmcjbgZqgnnMDJ83UQ0K5tZZ2ZraPcwC5xQmz5S0w6Y4iPoSHD'
}